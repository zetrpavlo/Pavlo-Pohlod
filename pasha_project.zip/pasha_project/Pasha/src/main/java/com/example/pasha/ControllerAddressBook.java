package com.example.pasha;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ControllerAddressBook implements AddressBook{
    @Override
    public void add(Person person) {
        personList.add(person);

    }

    @Override
    public void update(Person person) {

    }

    @Override
    public void delete(Person person) {
        personList.remove(person);

    }

    private ObservableList<Person> personList = FXCollections.observableArrayList();

    public void print(){
        int number = 0;

        for (Person person: personList){
            number++;
            System.out.println(number + ". PIP: " + person.getPip() + "; Phone:" + person.getPhone());
        }
    }

    public void fillTestData(){
        personList.add(new Person("Emil", "+38012345678"));
        personList.add(new Person("Vitaliya", "+38098765432"));
        personList.add(new Person("Vitaliy", "+38074185296"));
        personList.add(new Person("Artur", "+38085296374"));

    }


    public ObservableList<Person> getPersonList() {
        return personList;
    }

    public void setPersonList(ObservableList<Person> personList) {
        this.personList = personList;
    }
}

