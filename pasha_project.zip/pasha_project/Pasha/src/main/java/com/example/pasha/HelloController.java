package com.example.pasha;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;

public class HelloController {

    @FXML
    private Label welcomeText;

    @FXML
    private Button searchbtn;

    @FXML
    private Button deletebtn;

    @FXML
    private Button openbtn;

    @FXML
    private Button editbtn;

    @FXML
    private TextField searchrtxt;

    @FXML
    private Label labelCount;

    @FXML
    private TableView<Person> table;

    @FXML
    private Button Exitbutton;

    @FXML
    private TableColumn<Person, String> columnPip;

    @FXML
    private TableColumn<Person, String> columnPhone;

    @FXML
    private VBox scenePane;

    @FXML
    private ActionEvent actionEvent;

    public HelloController() {
    }

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }
    private Stage stage;

    private Stage newStage;
    private Stage editDialogStage;
    private Parent root;
    private FXMLLoader fxmlLoader = new FXMLLoader();
    private ControllerModalWindow controllerModalWindow;
    public void setNewStage(Stage newStage) {

        this.newStage = newStage;
    }
    ControllerAddressBook addressBookImpl = new ControllerAddressBook();

    @FXML
    public void initialize(){

        try {
            fxmlLoader.setLocation(HelloController.class.getResource("/com/example/pasha/ModalWindow.fxml"));
            root = fxmlLoader.load();
            controllerModalWindow = fxmlLoader.getController();
        } catch (IOException e) {
            e.printStackTrace();
        }

        columnPip.setCellValueFactory(new PropertyValueFactory<Person,String>("pip"));
        columnPhone.setCellValueFactory(new PropertyValueFactory<Person,String>("phone"));

        addressBookImpl.fillTestData();
        table.setItems(addressBookImpl.getPersonList());
    }
    @FXML
    void open(ActionEvent event) throws IOException {

        Button clickedButton = (Button) event.getSource();

        switch (clickedButton.getId()){
            case "openbtn":
                controllerModalWindow.setPerson(new Person());
                showDialog();
                addressBookImpl.add(controllerModalWindow.getPerson());
                break;
            case "editbtn":
                controllerModalWindow.setPerson((Person) table.getSelectionModel().getSelectedItem());
                showDialog();
                break;
            case "deletebtn":
                addressBookImpl.delete((Person) table.getSelectionModel().getSelectedItem());
                break;
        }
    }

    @FXML
    void edit(ActionEvent event) throws IOException {

        Button clickedButton = (Button) event.getSource();

        switch (clickedButton.getId()){
            case "openbtn":
                controllerModalWindow.setPerson(new Person());
                showDialog();
                addressBookImpl.add(controllerModalWindow.getPerson());
                break;
            case "editbtn":
                controllerModalWindow.setPerson((Person) table.getSelectionModel().getSelectedItem());
                showDialog();
                break;
            case "deletebtn":
                addressBookImpl.delete((Person) table.getSelectionModel().getSelectedItem());
                break;
        }
    }

    @FXML
    void delete(ActionEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION) ;
        alert.setTitle ("Видалення");
        alert.setContentText ("Ви впевненні, що хочете видалили запис? ");
        if (alert.showAndWait ().get() == null) {
            this.labelCount.setText("No selection! ");
        } else if (alert.showAndWait().get() == ButtonType.OK)  {
            this.labelCount.setText("Запис видалено ! ");
        } else if (alert.showAndWait().get() == ButtonType.CANCEL) {
            this.labelCount.setText("Відмінено ! ");
        } else {
            this.labelCount.setText("-");
        }

        Button clickedButton = (Button) event.getSource();

        switch (clickedButton.getId()){
            case "openbtn":
                controllerModalWindow.setPerson(new Person());
                showDialog();
                addressBookImpl.add(controllerModalWindow.getPerson());
                break;
            case "editbtn":
                controllerModalWindow.setPerson((Person) table.getSelectionModel().getSelectedItem());
                showDialog();
                break;
            case "deletebtn":
                addressBookImpl.delete((Person) table.getSelectionModel().getSelectedItem());
                break;

        }
    }

    @FXML
    public void showDialog(){
        editDialogStage = new Stage();
        Scene scene1 = new Scene(root);
        editDialogStage.setScene(scene1);
        scene1.getStylesheets().clear();
        File file = new File("@../../../../resources/com/example/pasha/my.css");
        String file_s = file.toURI().toString();
        scene1.getStylesheets().add(file_s);


        editDialogStage.setTitle("Редагування");
        editDialogStage.setMinHeight(170);
        editDialogStage.setMinWidth(600);
        editDialogStage.setResizable(false);
        editDialogStage.initOwner(newStage);
        editDialogStage.initModality(Modality.WINDOW_MODAL);
        editDialogStage.showAndWait();
    }

    @FXML
    public void searchfield(ActionEvent actionEvent) {
    }
    @FXML
    public void btnsearch(ActionEvent actionEvent) {
    }
    @FXML
    public void Exit(ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Вихід з програми");
        alert.setContentText("Ви дійсно бажаєте вийти ? ");
        if (alert.showAndWait().get() == ButtonType.OK) {
            Stage stage = (Stage) scenePane.getScene().getWindow();
            System.out.println("Ви успішно вийшли з програми");
            stage.close();
        }
    }

    @FXML
    public void openotherlabs(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloControllerOtherLabs.class.getResource("OtherLabs.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 950, 700);
        Stage stage = new Stage();
        stage.setTitle("Інші лабораторні");
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    public Stage getStage() {
        return stage;
    }
    @FXML
    public void setStage(Stage stage) {
        this.stage = stage;
    }
    @FXML
    public void setWelcomeText(Label welcomeText) {
        this.welcomeText = welcomeText;
    }
}
